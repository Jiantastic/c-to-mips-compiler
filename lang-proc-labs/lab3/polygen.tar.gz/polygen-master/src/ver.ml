(*
 * Polygen
 * ver.ml: version
 *
 * Alvise Spano' (2003)
 *)


let ver = "1.0.6"
let date = "20040628"
